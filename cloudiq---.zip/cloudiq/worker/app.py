"""CloudIQ worker: bounded CPU / memory / IO workloads + Prometheus metrics."""
import asyncio, os, random, time, uuid
import psutil
from fastapi import FastAPI, Response
from pydantic import BaseModel, Field
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Gauge, Histogram, generate_latest

WORKER_ID = os.getenv("WORKER_ID", "worker-1")
SLOW_FACTOR = float(os.getenv("SLOW_FACTOR", "1.0"))      # >1 simulates a weaker worker
MAX_SECONDS = float(os.getenv("MAX_WORK_SECONDS", "2.0"))  # hard cap per request
MAX_MEM_MB = int(os.getenv("MAX_MEM_MB", "64"))            # hard cap per request
ERROR_RATE = float(os.getenv("ERROR_RATE", "0"))           # error injection, off by default

app = FastAPI(title=f"CloudIQ {WORKER_ID}")
REQS = Counter("cloudiq_http_requests_total", "Requests", ["worker", "status"])
DUR = Histogram("cloudiq_http_request_duration_seconds", "Duration", ["worker"])
ACTIVE = Gauge("cloudiq_active_requests", "In-flight requests", ["worker"])
proc = psutil.Process()
proc.cpu_percent(None)


class Work(BaseModel):
    type: str = Field("cpu", pattern="^(cpu|memory|io)$")
    intensity: int = Field(3, ge=1, le=10)


def burn(seconds: float):
    end = time.perf_counter() + seconds
    x = 0
    while time.perf_counter() < end:
        x += sum(i * i for i in range(500))
    return x


@app.get("/health")
def health():
    return {"worker": WORKER_ID, "status": "ok"}


@app.get("/stats")
def stats():
    return {"worker": WORKER_ID, "process_cpu_percent": proc.cpu_percent(None),
            "process_memory_mb": proc.memory_info().rss / 1e6}


@app.post("/work")
async def work(w: Work):
    t0 = time.perf_counter()
    ACTIVE.labels(WORKER_ID).inc()
    status = "success"
    try:
        secs = min(MAX_SECONDS, 0.05 * w.intensity * SLOW_FACTOR)
        if ERROR_RATE and random.random() < ERROR_RATE:
            status = "error"
            return Response(status_code=500, content="injected error")
        if w.type == "cpu":
            await asyncio.to_thread(burn, secs)
        elif w.type == "memory":
            block = bytearray(min(MAX_MEM_MB, 4 * w.intensity) * 1024 * 1024)
            block[::4096] = b"x" * len(block[::4096])
            await asyncio.sleep(secs)
            del block
        else:
            await asyncio.sleep(secs)
        return {"worker": WORKER_ID, "request_id": uuid.uuid4().hex[:8], "workload": w.type,
                "duration": time.perf_counter() - t0, "timestamp": time.time(), "status": "success"}
    finally:
        ACTIVE.labels(WORKER_ID).dec()
        DUR.labels(WORKER_ID).observe(time.perf_counter() - t0)
        REQS.labels(WORKER_ID, status).inc()


@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
