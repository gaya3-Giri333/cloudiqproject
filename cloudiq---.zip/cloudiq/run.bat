@echo off
call .venv\Scripts\activate
REM worker-3 is deliberately 2.5x slower so smart routing has something to learn
start "worker-1" cmd /k "set WORKER_ID=worker-1&& python -m uvicorn worker.app:app --port 9001"
start "worker-2" cmd /k "set WORKER_ID=worker-2&& python -m uvicorn worker.app:app --port 9002"
start "worker-3" cmd /k "set WORKER_ID=worker-3&& set SLOW_FACTOR=2.5&& python -m uvicorn worker.app:app --port 9003"
timeout /t 3 >nul
start "gateway" cmd /k "python -m uvicorn backend.app:app --port 8000"
timeout /t 4 >nul
start http://127.0.0.1:8000
