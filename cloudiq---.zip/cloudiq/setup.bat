@echo off
REM Requires Python 3.12 (py launcher). Python 3.14 is NOT supported by these pins.
py -3.12 -m venv .venv || (echo Install Python 3.12 first & exit /b 1)
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo Setup done. Now run run.bat
