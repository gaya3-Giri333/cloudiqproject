"""CloudIQ control API + routing gateway (Round Robin, Least Connections, Random, ML risk-aware)."""
import asyncio, csv, itertools, os, random, time, uuid
from collections import deque
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from fastapi import Response
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Gauge, Histogram, generate_latest
from sklearn.ensemble import GradientBoostingRegressor

DECISIONS = Counter("cloudiq_routing_decisions_total", "Routing decisions", ["algorithm", "worker", "outcome"])
ROUTE_LAT = Histogram("cloudiq_routing_latency_seconds", "Latency seen by gateway", ["algorithm"])
HEALTH = Gauge("cloudiq_worker_health", "1 healthy, 0 down", ["worker"])


def _rec(d):
    decisions.appendleft(d)
    DECISIONS.labels(d["algorithm"], d["worker"] or "none", d["outcome"]).inc()
    if "latency" in d and d["outcome"] == "ok":
        ROUTE_LAT.labels(d["algorithm"]).observe(d["latency"])

URLS = os.getenv("WORKER_URLS", "http://127.0.0.1:9001,http://127.0.0.1:9002,http://127.0.0.1:9003").split(",")
SLA = float(os.getenv("LATENCY_SLA_SECONDS", "0.5"))
MAX_ACTIVE = int(os.getenv("MAX_ACTIVE_PER_WORKER", "10"))
W_ACTIVE = float(os.getenv("RISK_WEIGHT_ACTIVE", "0.3"))
HERE = Path(__file__).resolve().parent
CSV = HERE.parent / "ml" / "data" / "observations.csv"
TYPES = ["cpu", "memory", "io"]
ALGOS = ["round_robin", "least_connections", "random", "ml_predictive"]

workers = [dict(id=f"worker-{i+1}", idx=i, url=u.strip(), healthy=False, active=0, ewma=0.0, cpu=0.0,
                mem=0.0, completed=0, errors=0, err=None) for i, u in enumerate(URLS)]
state = dict(algorithm="least_connections", model=None, rr=itertools.count(), current=None)
decisions: deque = deque(maxlen=500)
experiments: list = []
observations: list = []  # rows: features + latency (measured from the running system)
model_status = dict(ready=False, rows=0, version=0, note="No model trained yet. Use 'Collect data & train'.")
client: httpx.AsyncClient


def load_obs():
    if CSV.exists():
        with open(CSV) as f:
            observations.extend([float(x) for x in r] for r in list(csv.reader(f))[1:])


def save_obs(row):
    new = not CSV.exists()
    CSV.parent.mkdir(parents=True, exist_ok=True)
    with open(CSV, "a", newline="") as f:
        wr = csv.writer(f)
        if new:
            wr.writerow(["worker_idx", "active", "ewma_latency", "cpu", "mem_mb", "type", "intensity", "latency"])
        wr.writerow(row)


async def poll():
    while True:
        for w in workers:
            try:
                d = (await client.get(w["url"] + "/stats", timeout=1.0)).json()
                HEALTH.labels(w["id"]).set(1)
                w.update(healthy=True, cpu=d["process_cpu_percent"], mem=d["process_memory_mb"], err=None)
            except Exception as e:
                HEALTH.labels(w["id"]).set(0)
                w.update(healthy=False, err=type(e).__name__)
        await asyncio.sleep(2)


@asynccontextmanager
async def lifespan(_):
    global client
    client = httpx.AsyncClient(timeout=15)
    load_obs()
    task = asyncio.create_task(poll())
    yield
    task.cancel()
    await client.aclose()


app = FastAPI(title="CloudIQ", lifespan=lifespan)


def feat(w, wt, inten):
    return [w["idx"], w["active"], w["ewma"], w["cpu"], w["mem"], TYPES.index(wt), inten]


def choose(algo, wt, inten):
    healthy = [w for w in workers if w["healthy"]]
    if not healthy:
        return None, {"reason": "no healthy workers"}
    if algo == "round_robin":
        for _ in range(len(workers)):
            w = workers[next(state["rr"]) % len(workers)]
            if w["healthy"]:
                return w, {"reason": "next healthy worker in rotation"}
    if algo == "random":
        return random.choice(healthy), {"reason": "random healthy worker"}
    if algo == "least_connections" or state["model"] is None:
        w = min(healthy, key=lambda x: (x["active"], x["id"]))
        why = "fewest active requests (tie-break by id)"
        if algo == "ml_predictive":
            why = "FALLBACK (model not ready): " + why
        return w, {"reason": why, "fallback": algo == "ml_predictive"}
    cands = {}
    for w in healthy:
        pred = float(state["model"].predict([feat(w, wt, inten)])[0])
        risk = pred / SLA + W_ACTIVE * w["active"] / MAX_ACTIVE
        safe = w["active"] < MAX_ACTIVE and pred <= 3 * SLA
        cands[w["id"]] = dict(pred_latency=round(pred, 4), risk=round(risk, 3), safe=safe)
    safe = {k: v for k, v in cands.items() if v["safe"]}
    if not safe:
        return None, {"reason": "all candidates unsafe (overload protection)", "candidates": cands}
    best = min(safe, key=lambda k: safe[k]["risk"])
    return next(w for w in workers if w["id"] == best), {
        "reason": f"lowest risk {safe[best]['risk']} (predicted latency {safe[best]['pred_latency']}s)",
        "candidates": cands, "pred": safe[best]["pred_latency"]}


async def route(algo, wt, inten, record=True):
    w, info = choose(algo, wt, inten)
    d = {"id": uuid.uuid4().hex[:8], "ts": time.time(), "algorithm": algo, "workload": wt,
         "intensity": inten, "worker": w["id"] if w else None, **info}
    if w is None:
        d.update(outcome="rejected")
        _rec(d)
        return d
    f = feat(w, wt, inten)
    w["active"] += 1
    t0 = time.perf_counter()
    ok = False
    try:
        ok = (await client.post(w["url"] + "/work", json={"type": wt, "intensity": inten})).status_code == 200
    except Exception:
        pass
    finally:
        w["active"] -= 1  # always released
    lat = time.perf_counter() - t0
    w["completed"] += 1
    w["errors"] += 0 if ok else 1
    if ok:
        w["ewma"] = lat if w["ewma"] == 0 else 0.8 * w["ewma"] + 0.2 * lat
        if record:
            observations.append(f + [lat])
            save_obs(f + [lat])
    d.update(outcome="ok" if ok else "error", latency=round(lat, 4))
    if "pred" in d and ok:
        d["prediction_error"] = round(abs(d["pred"] - lat), 4)
        others = [v["pred_latency"] for k, v in d["candidates"].items() if k != d["worker"]]
        if others:  # ESTIMATE only: alternatives were not actually tested
            d["regret_estimate"] = round(max(0.0, lat - min(others)), 4)
    _rec(d)
    return d


class WL(BaseModel):
    algorithm: str = "least_connections"
    requests: int = Field(100, ge=1, le=2000)
    concurrency: int = Field(10, ge=1, le=50)
    workload: str = Field("mixed", pattern="^(mixed|cpu|memory|io)$")
    intensity: int = Field(3, ge=1, le=10)
    seed: int = 42


async def run_workload(cfg: WL, save=True):
    rng = random.Random(cfg.seed)  # same seed => identical request sequence for fair comparison
    jobs = [(rng.choice(TYPES) if cfg.workload == "mixed" else cfg.workload,
             rng.randint(1, cfg.intensity)) for _ in range(cfg.requests)]
    sem = asyncio.Semaphore(cfg.concurrency)
    results, done = [], 0
    state["current"] = dict(running=True, done=0, total=cfg.requests, algorithm=cfg.algorithm)

    async def one(j):
        nonlocal done
        async with sem:
            results.append(await route(cfg.algorithm, j[0], j[1]))
            done += 1
            state["current"]["done"] = done

    t0 = time.perf_counter()
    await asyncio.gather(*[one(j) for j in jobs])
    el = time.perf_counter() - t0
    lats = [r["latency"] for r in results if r["outcome"] == "ok"]
    dist = {w["id"]: sum(1 for r in results if r["worker"] == w["id"]) for w in workers}
    errs = [r["prediction_error"] for r in results if "prediction_error" in r]
    reg = [r["regret_estimate"] for r in results if "regret_estimate" in r]
    pct = lambda p: round(float(np.percentile(lats, p)), 4) if lats else None
    summ = dict(id=uuid.uuid4().hex[:8], ts=time.time(), config=cfg.model_dump(), duration_s=round(el, 3),
                throughput_rps=round(len(lats) / el, 2), mean=round(float(np.mean(lats)), 4) if lats else None,
                p50=pct(50), p95=pct(95), p99=pct(99),
                error_rate=round(sum(r["outcome"] == "error" for r in results) / len(results), 4),
                rejected=sum(r["outcome"] == "rejected" for r in results),
                sla_violations=sum(l > SLA for l in lats), distribution=dist,
                mean_prediction_error=round(float(np.mean(errs)), 4) if errs else None,
                mean_regret_estimate=round(float(np.mean(reg)), 4) if reg else None)
    state["current"]["running"] = False
    if save:
        experiments.insert(0, summ)
    return summ


def train():
    n = len(observations)
    if n < 40:
        raise HTTPException(400, f"Need at least 40 observations, have {n}.")
    data = np.array(observations)
    cut = int(n * 0.75)  # chronological split: test rows are strictly later than training rows
    Xtr, ytr, Xte, yte = data[:cut, :-1], data[:cut, -1], data[cut:, :-1], data[cut:, -1]
    m = GradientBoostingRegressor(n_estimators=150, max_depth=3, random_state=0).fit(Xtr, ytr)
    p = m.predict(Xte)
    base = np.full_like(yte, ytr.mean())
    state["model"] = GradientBoostingRegressor(n_estimators=150, max_depth=3, random_state=0).fit(data[:, :-1], data[:, -1])
    model_status.update(ready=True, rows=n, version=model_status["version"] + 1, trained_at=time.time(),
                        mae=round(float(np.mean(abs(p - yte))), 4), rmse=round(float(np.sqrt(np.mean((p - yte) ** 2))), 4),
                        baseline_mae=round(float(np.mean(abs(base - yte))), 4), test_rows=n - cut,
                        note="Target: request latency (s). Trained on observations from this running system (not synthetic). "
                             "Metrics from a time-ordered hold-out; final model refit on all rows.")
    return model_status


# ---------------- API ----------------
@app.get("/api/v1/health")
def health():
    return {"status": "ok", "healthy_workers": sum(w["healthy"] for w in workers), "total_workers": len(workers),
            "mode": "local"}


@app.get("/api/v1/workers")
def get_workers():
    return workers


@app.get("/api/v1/algorithms")
def algos():
    return {"available": ALGOS, "active": state["algorithm"]}


class Act(BaseModel):
    algorithm: str


@app.put("/api/v1/algorithms/active")
def set_algo(a: Act):
    if a.algorithm not in ALGOS:
        raise HTTPException(422, f"Unknown algorithm. Choose from {ALGOS}")
    state["algorithm"] = a.algorithm
    return algos()


@app.post("/api/v1/route")
async def route_one(workload: str = "cpu", intensity: int = 3):
    if workload not in TYPES or not 1 <= intensity <= 10:
        raise HTTPException(422, "invalid workload/intensity")
    return await route(state["algorithm"], workload, intensity)


@app.post("/api/v1/workloads/start")
async def start(cfg: WL):
    if cfg.algorithm not in ALGOS:
        raise HTTPException(422, "Unknown algorithm")
    if state["current"] and state["current"]["running"]:
        raise HTTPException(409, "A workload is already running")
    state["current"] = dict(running=True, done=0, total=cfg.requests, algorithm=cfg.algorithm)
    asyncio.create_task(run_workload(cfg))
    return state["current"]


@app.get("/api/v1/workloads/status")
def wl_status():
    return state["current"] or {"running": False}


@app.get("/api/v1/decisions")
def get_decisions(limit: int = 30):
    return list(decisions)[:limit]


@app.get("/api/v1/experiments")
def get_exps():
    return experiments


@app.get("/api/v1/model/status")
def mstatus():
    return model_status


@app.post("/api/v1/model/train")
def mtrain():
    return train()


@app.post("/api/v1/model/collect")
async def collect(n: int = 200):
    if state["current"] and state["current"]["running"]:
        raise HTTPException(409, "A workload is already running")
    n = max(40, min(n, 1000))
    asyncio.create_task(_collect(n))
    return {"started": True, "requests": n}


async def _collect(n):
    await run_workload(WL(algorithm="random", requests=n, concurrency=8, workload="mixed", intensity=8, seed=int(time.time()) % 10000), save=False)
    try:
        train()
    except HTTPException as e:
        model_status["note"] = e.detail


@app.get("/")
def index():
    return FileResponse(HERE / "static" / "index.html")


@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
