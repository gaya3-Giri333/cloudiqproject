import itertools
from backend import app as a

def reset(h=(True, True, True), act=(0, 0, 0)):
    for w, hh, ac in zip(a.workers, h, act):
        w.update(healthy=hh, active=ac)
    a.state["rr"] = itertools.count()
    a.state["model"] = None

def test_round_robin_skips_unhealthy():
    reset(h=(True, False, True))
    ids = [a.choose("round_robin", "cpu", 1)[0]["id"] for _ in range(4)]
    assert ids == ["worker-1", "worker-3", "worker-1", "worker-3"]

def test_least_connections():
    reset(act=(3, 1, 2))
    assert a.choose("least_connections", "cpu", 1)[0]["id"] == "worker-2"

def test_all_unhealthy():
    reset(h=(False, False, False))
    assert a.choose("least_connections", "cpu", 1)[0] is None

def test_ml_falls_back_without_model():
    reset(act=(2, 0, 2))
    w, info = a.choose("ml_predictive", "cpu", 1)
    assert w["id"] == "worker-2" and info["fallback"]
