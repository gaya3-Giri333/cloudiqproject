FROM python:3.12-slim
WORKDIR /app
COPY requirements-worker.txt .
RUN pip install --no-cache-dir -r requirements-worker.txt
COPY worker ./worker
RUN useradd -m app && chown -R app /app
USER app
EXPOSE 8000
CMD ["python", "-m", "uvicorn", "worker.app:app", "--host", "0.0.0.0", "--port", "8000"]
