# CloudIQ (local mode)
Windows, Python 3.12. No Docker needed.
1. `setup.bat`  2. `run.bat` (opens 3 workers + gateway, then http://127.0.0.1:8000)
3. In the dashboard: **Collect data & train**, then run the same experiment (same seed) with each algorithm and compare.
Tests: `.venv\Scripts\activate` then `pytest backend/tests`. API docs: http://127.0.0.1:8000/docs
Not included yet: Docker/Compose, Kubernetes/Minikube, Prometheus/Grafana configs, PostgreSQL, React frontend, auth.
Workers already expose Prometheus `/metrics`. worker-3 is artificially slower (SLOW_FACTOR=2.5): results are for a simulated heterogeneous setup.

## Docker mode (needs Docker Desktop)
`docker compose up --build` then open: dashboard http://localhost:8000, Prometheus http://localhost:9090 (Status > Targets: expect 4 UP), Grafana http://localhost:3000 (user `admin`, password from `.env`/default `change-me`; dashboard "CloudIQ Infrastructure").
Stop: `docker compose down`. If a target is DOWN: `docker compose logs <service>`.
